# Editable EGU27 artwork

Compile main.tex with pdfLaTeX for the Instagram layout, or compile linkedin.tex for the landscape layout. Keep all files together. No external images are required.

Edit content.tex for wording, deadlines and embedded links. Edit campaign.sty for colours, typography and the original TikZ illustration.

The full repository includes a Python build helper for exact-size PNG exports.
